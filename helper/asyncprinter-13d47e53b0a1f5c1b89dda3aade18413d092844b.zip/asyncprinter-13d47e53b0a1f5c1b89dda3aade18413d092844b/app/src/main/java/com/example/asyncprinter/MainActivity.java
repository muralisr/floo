package com.example.asyncprinter;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import org.apache.commons.lang3.ClassUtils;

import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.asyncprinter.databinding.ActivityMainBinding;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private String object1;
    private int integer1;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        System.out.println("FLOO: Going to print time 25 times.");
        ArrayList<String> al = new ArrayList<>();
        for (int i = 0; i < 25; i++) {
            String sig = "Info:" + String.valueOf(i);
            Helper.addInfo(sig);
        }
        System.out.println("FLOO: Finished printing time 25 times.");
        try {
            this.someFunction("hello");
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public void someFunction(String s) throws InstantiationException, IllegalAccessException {
        // assuming Soot can prefill all this and create this line
        String fn1 = "Function #1";
        ArrayList<Object> l1 = new ArrayList<Object>() {
            {
                add("this is a string primitive");
                add(new ArrayList<Integer>(
                        Arrays.asList(1, 2, 3)));
                add(new ReadState("reading", 1));
                add(new ArrayList<ReadState>(
                        Arrays.asList(new ReadState("read1", 1),
                                new ReadState("read2", 2),
                                new ReadState("read3", 3))));
            }
        };
        String fn2 = "Function #1";
        ArrayList<Object> l2 = new ArrayList<Object>() {
            {
                add("this is a string primitive");
                add(new ArrayList<Integer>(
                        Arrays.asList(1, 2, 3)));
                add(new ReadState("reading", 1));
                add(new ArrayList<ReadState>(
                        Arrays.asList(new ReadState("read1", 1),
                                new ReadState("read2", 2),
                                new ReadState("read3", 3))));
            }
        };
        assertReflectionEquals(l1, l2);
        HelperDeepEquals.addFunctionObj(fn1,l1);
        HelperDeepEquals.addFunctionObj(fn2,l2);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}