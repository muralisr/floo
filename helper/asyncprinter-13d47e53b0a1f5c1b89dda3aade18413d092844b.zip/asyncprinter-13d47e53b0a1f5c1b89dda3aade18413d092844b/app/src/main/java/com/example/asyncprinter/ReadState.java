package com.example.asyncprinter;

public class ReadState {
    private String read;
    private int num;

    public ReadState() {

    }

    public ReadState(String read, int num) {
        this.read = read;
        this.num = num;
    }

    public String getRead() {
        return this.read;
    }

    public int getNum() {
        final int num = this.num;
        return num;
    }
}
