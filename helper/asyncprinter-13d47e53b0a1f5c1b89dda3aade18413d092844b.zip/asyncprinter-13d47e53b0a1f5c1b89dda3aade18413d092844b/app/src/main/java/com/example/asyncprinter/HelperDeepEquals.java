package com.example.asyncprinter;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import junit.framework.AssertionFailedError;
import org.apache.commons.lang3.ClassUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;


public class HelperDeepEquals {

    public static ArrayList<FunctionRunInfoDeep> listOfFunctionRunInfo = new ArrayList<>();
    private static Executor functionInfoAdder = Executors.newSingleThreadExecutor();

    // Class used to keep track of each objects used for particular function call
    public static class FunctionRunInfoDeep {
        public String functionName;
        public ArrayList<Object> listOfObjects = new ArrayList<>();

        // constructor
        public FunctionRunInfoDeep(String functionName, ArrayList<Object> listOfObjects) throws InstantiationException, IllegalAccessException {
            this.functionName = functionName;
            for (Object obj: listOfObjects) {
                // make a deep copy
                Object deepCopyOfObject = this.copy(obj);
                // add to the list of objects for this FunctionRunInfo
                this.listOfObjects.add(deepCopyOfObject);
            }
        }

        // make a deep copy of a given object
        private <T> T copy(T entity) throws IllegalAccessException, InstantiationException {
            Class<?> clazz = entity.getClass();
            T newEntity = (T) entity.getClass().newInstance();

            while (clazz != null) {
                copyFields(entity, newEntity, clazz);
                clazz = clazz.getSuperclass();
            }

            return newEntity;
        }

        // copies over field
        private <T> T copyFields(T entity, T newEntity, Class<?> clazz) throws IllegalAccessException {
            List<Field> fields = new ArrayList<>();
            for (Field field : clazz.getDeclaredFields()) {
                fields.add(field);
            }
            for (Field field : fields) {
                field.setAccessible(true);
                field.set(newEntity, field.get(entity));
            }
            return newEntity;
        }
    }

    // Call this function to add function details to the in memory record
    public static void addFunctionObj(String functionName, ArrayList<Object> listOfObjects) throws IllegalAccessException, InstantiationException {
        // asynchronously
        functionInfoAdder.execute(() -> {
            try {
                // making deep copy
                FunctionRunInfoDeep item = new FunctionRunInfoDeep(functionName, listOfObjects);
                boolean repeat = false;
                if (listContainsFunctionRunInfo(item)) {
                    repeat = true;
                } else {
                    listOfFunctionRunInfo.add(item);
                }
                if (repeat) {
                    System.out.println("Can memoize function call for" + functionName);
                }
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        });
    }

    private static boolean listContainsFunctionRunInfo(FunctionRunInfoDeep item) {
        boolean listContains = false;
        for (FunctionRunInfoDeep f1: listOfFunctionRunInfo) {
            if ((f1.functionName.equals(item.functionName))) {
                functionInfoContainSameObj(f1.listOfObjects, item.listOfObjects);
                listContains = true;
            }
        }
        return listContains;
    }

    private static boolean functionInfoContainSameObj(ArrayList<Object> objectList1, ArrayList<Object> objectList2) {
        try {
            assertReflectionEquals(objectList1, objectList2);
            return true;
        } catch (AssertionError e) {
            return false;
        }
    }
}
